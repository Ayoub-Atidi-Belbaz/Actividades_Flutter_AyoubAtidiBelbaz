// 11 · Elevar el estado: la pantalla guarda los favoritos y las tarjetas
// (Stateless) reciben el valor y avisan con un callback.
import 'package:flutter/material.dart';

void main() => runApp(const MaterialApp(home: Catalogo()));

class Catalogo extends StatefulWidget {
  const Catalogo({super.key});

  @override
  State<Catalogo> createState() => _CatalogoState();
}

class _CatalogoState extends State<Catalogo> {
  static const libros = ['Don Quijote', 'Cosmos', 'Sapiens', 'Maus'];
  final Set<String> _favoritos = {};

  void _alternar(String libro) {
    setState(() {
      if (_favoritos.contains(libro)) {
        _favoritos.remove(libro);
      } else {
        _favoritos.add(libro);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // La AppBar puede contar porque el dato está en la pantalla
      appBar: AppBar(title: Text('Favoritos: ${_favoritos.length}')),
      body: ListView(
        children: [
          for (final libro in libros)
            TarjetaLibro(
              key: ValueKey(libro),
              titulo: libro,
              favorito: _favoritos.contains(libro), // dato hacia abajo
              onFavorito: () => _alternar(libro),   // evento hacia arriba
            ),
        ],
      ),
    );
  }
}

class TarjetaLibro extends StatelessWidget {
  const TarjetaLibro({
    super.key,
    required this.titulo,
    required this.favorito,
    required this.onFavorito,
  });

  final String titulo;
  final bool favorito;
  final VoidCallback onFavorito;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(titulo),
      trailing: IconButton(
        icon: Icon(favorito ? Icons.favorite : Icons.favorite_border),
        color: favorito ? Colors.red : null,
        onPressed: onFavorito,
      ),
    );
  }
}
