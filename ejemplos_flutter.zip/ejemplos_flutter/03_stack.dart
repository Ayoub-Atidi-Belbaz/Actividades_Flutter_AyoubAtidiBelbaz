// 03 · Stack: superponer widgets (texto sobre una "portada").
import 'package:flutter/material.dart';

void main() => runApp(const MaterialApp(home: EjemploStack()));

class EjemploStack extends StatelessWidget {
  const EjemploStack({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Stack')),
      body: Center(
        child: Stack(
          children: [
            // Fondo: ocupa el tamaño del Stack
            Container(width: 200, height: 280, color: Colors.indigo),
            // Etiqueta en la esquina superior derecha
            Positioned(
              top: 8,
              right: 8,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                color: Colors.amber,
                child: const Text('NUEVO'),
              ),
            ),
            // Título abajo
            const Positioned(
              left: 12,
              bottom: 12,
              child: Text(
                'Don Quijote',
                style: TextStyle(color: Colors.white, fontSize: 22),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
