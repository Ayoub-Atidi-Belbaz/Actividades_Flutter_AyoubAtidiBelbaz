// 10 · Carga asíncrona: estados de carga, error y datos con FutureBuilder.
import 'dart:math';

import 'package:flutter/material.dart';

void main() => runApp(const MaterialApp(home: CargaLibros()));

/// Simula una petición a un servidor: tarda 2 s y a veces falla.
Future<List<String>> descargarLibros() async {
  await Future.delayed(const Duration(seconds: 2));
  if (Random().nextBool()) throw Exception('Sin conexión');
  return ['Don Quijote', 'Cosmos', 'Sapiens', 'Maus'];
}

class CargaLibros extends StatefulWidget {
  const CargaLibros({super.key});

  @override
  State<CargaLibros> createState() => _CargaLibrosState();
}

class _CargaLibrosState extends State<CargaLibros> {
  // El Future se crea una vez (en initState), nunca dentro de build
  late Future<List<String>> _futuro;

  @override
  void initState() {
    super.initState();
    _futuro = descargarLibros();
  }

  void _reintentar() => setState(() => _futuro = descargarLibros());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Carga asíncrona')),
      body: FutureBuilder<List<String>>(
        future: _futuro,
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text('Error: ${snapshot.error}'),
                  TextButton(onPressed: _reintentar, child: const Text('Reintentar')),
                ],
              ),
            );
          }
          final libros = snapshot.data!;
          return ListView(
            children: [for (final l in libros) ListTile(title: Text(l))],
          );
        },
      ),
    );
  }
}
