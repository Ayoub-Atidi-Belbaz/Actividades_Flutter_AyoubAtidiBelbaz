# Ejemplos sencillos de Flutter · UD1

Cada fichero es un `main.dart` completo e independiente.

**Cómo usarlos**
- En el navegador: copiar el contenido en https://dartpad.dev y pulsar *Run*.
- En local: `flutter create ejemplos`, sustituir `lib/main.dart` por el ejemplo y `flutter run`.

| Nº | Fichero | Qué enseña | Sesión (propuesta B) |
|----|---------|------------|----------------------|
| 01 | 01_hola_mundo.dart | MaterialApp, Scaffold, AppBar, Text | 3 |
| 02 | 02_row_column.dart | Row, Column, alineación, Expanded, SizedBox | 4 |
| 03 | 03_stack.dart | Stack y Positioned | 4 |
| 04 | 04_listview_builder.dart | ListView.builder y ListTile | 4 |
| 05 | 05_contador_stateful.dart | StatefulWidget, setState, botón deshabilitado con null | 5 |
| 06 | 06_textfield_onchanged.dart | TextField, onChanged, SnackBar | 7 |
| 07 | 07_gesture_detector.dart | GestureDetector: tap, doble tap, pulsación larga | 8 |
| 08 | 08_formulario_validacion.dart | Form, GlobalKey, validator, dispose | 11 |
| 09 | 09_navegacion_datos.dart | push, pop con resultado, datos por constructor | 11 |
| 10 | 10_carga_asincrona.dart | Future, FutureBuilder, estados de carga y error | 12 |
| 11 | 11_estado_elevado.dart | Elevar el estado, callbacks, ValueKey | 6 |
| 12 | 12_dismissible.dart | Dismissible, keys, deshacer | 7 |
| 13 | 13_tema.dart | ThemeData, ColorScheme, modo oscuro | 10 |

**Ideas para clase:** ejecutar el ejemplo, pedir una predicción ("¿qué pasa si quito el setState?", "¿y si quito el Expanded?") y hacer el cambio en directo con hot reload.
