// 02 · Row y Column: ejes, alineación, Expanded y SizedBox.
import 'package:flutter/material.dart';

void main() => runApp(const MaterialApp(home: RowColumn()));

class RowColumn extends StatelessWidget {
  const RowColumn({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Row y Column')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch, // ocupar todo el ancho
          children: [
            // Tres cajas repartidas en una fila
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _caja(Colors.red),
                _caja(Colors.green),
                _caja(Colors.blue),
              ],
            ),
            const SizedBox(height: 24),
            // Expanded reparte el espacio sobrante (1 parte y 2 partes)
            Row(
              children: [
                Expanded(flex: 1, child: Container(height: 50, color: Colors.orange)),
                Expanded(flex: 2, child: Container(height: 50, color: Colors.purple)),
              ],
            ),
            const SizedBox(height: 24),
            // Un texto largo que no desborda gracias a Expanded
            const Row(
              children: [
                Icon(Icons.info),
                SizedBox(width: 8),
                Expanded(
                  child: Text('Este texto es largo, pero Expanded le da el ancho '
                      'que queda y hace salto de línea en lugar de desbordar.'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _caja(Color color) => Container(width: 80, height: 80, color: color);
}
