// 06 · TextField con onChanged: la interfaz reacciona mientras se escribe.
import 'package:flutter/material.dart';

void main() => runApp(const MaterialApp(home: Saludo()));

class Saludo extends StatefulWidget {
  const Saludo({super.key});

  @override
  State<Saludo> createState() => _SaludoState();
}

class _SaludoState extends State<Saludo> {
  String _nombre = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('onChanged')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              decoration: const InputDecoration(
                labelText: 'Tu nombre',
                border: OutlineInputBorder(),
              ),
              onChanged: (texto) => setState(() => _nombre = texto),
            ),
            const SizedBox(height: 16),
            Text(
              _nombre.isEmpty ? 'Escribe algo…' : 'Hola, $_nombre',
              style: const TextStyle(fontSize: 24),
            ),
            Text('${_nombre.length} caracteres'),
            const SizedBox(height: 16),
            ElevatedButton(
              // Se activa solo con 3 caracteres o más
              onPressed: _nombre.trim().length >= 3
                  ? () => ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Bienvenido, $_nombre')),
                      )
                  : null,
              child: const Text('Entrar'),
            ),
          ],
        ),
      ),
    );
  }
}
