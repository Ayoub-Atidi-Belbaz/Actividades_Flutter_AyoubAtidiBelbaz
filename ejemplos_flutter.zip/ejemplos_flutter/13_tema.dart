// 13 · ThemeData: colores y estilos centralizados, con modo oscuro.
import 'package:flutter/material.dart';

void main() => runApp(const AppConTema());

class AppConTema extends StatefulWidget {
  const AppConTema({super.key});

  @override
  State<AppConTema> createState() => _AppConTemaState();
}

class _AppConTemaState extends State<AppConTema> {
  bool _oscuro = false;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      // Cambiar la semilla cambia TODOS los colores de la app
      theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: Colors.teal)),
      darkTheme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.teal,
          brightness: Brightness.dark,
        ),
      ),
      themeMode: _oscuro ? ThemeMode.dark : ThemeMode.light,
      home: Builder(
        // Builder da un context que ya está "dentro" del MaterialApp
        builder: (context) {
          final colores = Theme.of(context).colorScheme;
          final textos = Theme.of(context).textTheme;
          return Scaffold(
            appBar: AppBar(
              title: const Text('Tema'),
              backgroundColor: colores.primaryContainer,
            ),
            body: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text('Título grande', style: textos.headlineMedium),
                  Text('Texto normal', style: textos.bodyLarge),
                  const SizedBox(height: 16),
                  FilledButton(onPressed: () {}, child: const Text('Botón principal')),
                  SwitchListTile(
                    title: const Text('Modo oscuro'),
                    value: _oscuro,
                    onChanged: (v) => setState(() => _oscuro = v),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
