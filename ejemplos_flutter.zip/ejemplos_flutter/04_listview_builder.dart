// 04 · ListView.builder: listas largas que solo construyen lo visible.
import 'package:flutter/material.dart';

void main() => runApp(const MaterialApp(home: Lista()));

class Lista extends StatelessWidget {
  const Lista({super.key});

  static const libros = [
    'Don Quijote', 'Cosmos', 'Sapiens', 'Maus', 'La colmena',
    'Persépolis', 'Breve historia del tiempo', 'Fahrenheit 451',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ListView.builder')),
      body: ListView.builder(
        itemCount: libros.length,
        itemBuilder: (context, index) {
          return ListTile(
            leading: CircleAvatar(child: Text('${index + 1}')),
            title: Text(libros[index]),
            trailing: const Icon(Icons.chevron_right),
          );
        },
      ),
    );
  }
}
