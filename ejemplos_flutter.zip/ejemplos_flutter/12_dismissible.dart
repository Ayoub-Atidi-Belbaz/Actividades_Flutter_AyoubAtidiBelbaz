// 12 · Dismissible: deslizar para borrar, con "Deshacer".
import 'package:flutter/material.dart';

void main() => runApp(const MaterialApp(home: Tareas()));

class Tareas extends StatefulWidget {
  const Tareas({super.key});

  @override
  State<Tareas> createState() => _TareasState();
}

class _TareasState extends State<Tareas> {
  final _tareas = ['Estudiar Dart', 'Hacer la práctica', 'Subir a GitHub', 'Repasar widgets'];

  void _borrar(int index) {
    final tarea = _tareas[index];
    setState(() => _tareas.removeAt(index)); // obligatorio quitarla de la lista
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('"$tarea" borrada'),
        action: SnackBarAction(
          label: 'Deshacer',
          onPressed: () => setState(() => _tareas.insert(index, tarea)),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Desliza para borrar')),
      body: ListView.builder(
        itemCount: _tareas.length,
        itemBuilder: (context, index) {
          final tarea = _tareas[index];
          return Dismissible(
            key: ValueKey(tarea), // la key sale del dato, no del índice
            background: Container(
              color: Colors.red,
              alignment: Alignment.centerLeft,
              padding: const EdgeInsets.only(left: 16),
              child: const Icon(Icons.delete, color: Colors.white),
            ),
            onDismissed: (_) => _borrar(index),
            child: ListTile(title: Text(tarea)),
          );
        },
      ),
    );
  }
}
