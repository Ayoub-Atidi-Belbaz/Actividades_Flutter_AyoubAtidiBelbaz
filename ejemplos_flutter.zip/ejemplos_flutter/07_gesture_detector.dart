// 07 · GestureDetector: toque, doble toque y pulsación larga.
import 'package:flutter/material.dart';

void main() => runApp(const MaterialApp(home: Gestos()));

class Gestos extends StatefulWidget {
  const Gestos({super.key});

  @override
  State<Gestos> createState() => _GestosState();
}

class _GestosState extends State<Gestos> {
  String _ultimo = 'Ninguno';
  bool _favorito = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Gestos')),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            GestureDetector(
              onTap: () => setState(() => _ultimo = 'Toque'),
              onDoubleTap: () => setState(() {
                _ultimo = 'Doble toque';
                _favorito = !_favorito;
              }),
              onLongPress: () => setState(() => _ultimo = 'Pulsación larga'),
              child: Container(
                width: 200,
                height: 200,
                color: Colors.indigo.shade100,
                alignment: Alignment.center,
                child: Icon(
                  _favorito ? Icons.favorite : Icons.favorite_border,
                  size: 80,
                  color: Colors.red,
                ),
              ),
            ),
            const SizedBox(height: 24),
            Text('Último gesto: $_ultimo', style: const TextStyle(fontSize: 20)),
            const SizedBox(height: 8),
            const Text('Doble toque para marcar como favorito'),
          ],
        ),
      ),
    );
  }
}
