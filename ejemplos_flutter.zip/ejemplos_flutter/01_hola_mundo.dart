// 01 · Hola mundo: MaterialApp, Scaffold, AppBar y Text.
import 'package:flutter/material.dart';

void main() => runApp(const MaterialApp(home: HolaMundo()));

class HolaMundo extends StatelessWidget {
  const HolaMundo({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mi primera app')),
      body: const Center(
        child: Text('¡Hola, Flutter!', style: TextStyle(fontSize: 28)),
      ),
    );
  }
}
