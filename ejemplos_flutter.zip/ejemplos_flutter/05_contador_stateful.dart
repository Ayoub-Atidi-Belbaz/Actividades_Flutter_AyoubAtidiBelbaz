// 05 · StatefulWidget y setState: el contador clásico, ampliado.
import 'package:flutter/material.dart';

void main() => runApp(const MaterialApp(home: Contador()));

class Contador extends StatefulWidget {
  const Contador({super.key});

  @override
  State<Contador> createState() => _ContadorState();
}

class _ContadorState extends State<Contador> {
  int _valor = 0; // el estado vive aquí, no en el widget

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Contador')),
      body: Center(
        child: Text(
          '$_valor',
          style: TextStyle(
            fontSize: 72,
            color: _valor > 10 ? Colors.red : null, // cambia al pasar de 10
          ),
        ),
      ),
      floatingActionButton: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          FloatingActionButton(
            heroTag: 'menos',
            // null deshabilita el botón cuando el valor es 0
            onPressed: _valor == 0 ? null : () => setState(() => _valor--),
            child: const Icon(Icons.remove),
          ),
          const SizedBox(width: 12),
          FloatingActionButton(
            heroTag: 'mas',
            onPressed: () => setState(() => _valor++),
            child: const Icon(Icons.add),
          ),
        ],
      ),
    );
  }
}
