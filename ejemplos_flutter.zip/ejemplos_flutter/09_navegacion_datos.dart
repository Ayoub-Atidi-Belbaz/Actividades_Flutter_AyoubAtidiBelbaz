// 09 · Navegación: pasar datos a otra pantalla y recibir un resultado.
import 'package:flutter/material.dart';

void main() => runApp(const MaterialApp(home: ListaColores()));

class ListaColores extends StatefulWidget {
  const ListaColores({super.key});

  @override
  State<ListaColores> createState() => _ListaColoresState();
}

class _ListaColoresState extends State<ListaColores> {
  String _elegido = 'ninguno';

  Future<void> _abrir(String color) async {
    // push devuelve un Future con lo que la otra pantalla pase a pop()
    final respuesta = await Navigator.of(context).push<bool>(
      MaterialPageRoute(builder: (_) => DetalleColor(nombre: color)),
    );
    if (respuesta == true) {
      setState(() => _elegido = color);
    }
  }

  @override
  Widget build(BuildContext context) {
    const colores = ['Rojo', 'Verde', 'Azul'];
    return Scaffold(
      appBar: AppBar(title: Text('Elegido: $_elegido')),
      body: ListView(
        children: [
          for (final c in colores)
            ListTile(title: Text(c), onTap: () => _abrir(c)),
        ],
      ),
    );
  }
}

class DetalleColor extends StatelessWidget {
  const DetalleColor({super.key, required this.nombre});

  final String nombre; // dato recibido por constructor

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(nombre)),
      body: Center(
        child: ElevatedButton(
          // pop con valor: vuelve atrás y entrega el resultado
          onPressed: () => Navigator.of(context).pop(true),
          child: Text('Elegir $nombre'),
        ),
      ),
    );
  }
}
